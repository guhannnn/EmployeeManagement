package employeedao;

import java.util.List;

import model.EmpPersonalDetails;
import model.Employee;

public interface EmployeeDao {
    void create(Employee employee);

    List<Employee> readAll();

    abstract Employee read(int id);

    abstract Employee read(String fullname);
    void update(Employee employee);

    void delete(int id);
    void createDetails(EmpPersonalDetails ed);
}
